package com.example.aes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Base64;
import android.widget.TextView;

import com.example.aes.databinding.ActivityMainBinding;

import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'aes' library on application startup.
    static {
        System.loadLibrary("aes");
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        TextView tv = binding.sampleText;
        tv.setText(openssl_encrypt("1111222233334444".getBytes(StandardCharsets.UTF_8), "1234567890123456".getBytes(StandardCharsets.UTF_8)));
    }

    /**
     * A native method that is implemented by the 'aes' native library,
     * which is packaged with this application.
     */

    public static native String  openssl_encrypt(byte[] data, byte[] key);


    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}