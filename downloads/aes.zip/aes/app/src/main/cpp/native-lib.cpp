#include <jni.h>
#include <string>
//#include "aes128.c"
#include "aes.c"
#include "aes.h"


extern "C" JNIEXPORT jstring JNICALL
Java_com_example_aes_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}
//extern "C"
//JNIEXPORT jbyteArray JNICALL
//Java_com_example_aes_MainActivity_encryptECB(JNIEnv *env, jclass clazz, jbyteArray key_, jbyteArray input_) {
//
//    jbyte key[16];
//    jbyte input[16];
//    jbyte output[16];
//
//    env->GetByteArrayRegion(key_, 0, 16, key);
//    env->GetByteArrayRegion( input_, 0, 16, input);
//
//    aes128_encrypt_block((uint8_t *)key, (uint8_t *)input, (uint8_t *)output);
//
//    jbyteArray result = env->NewByteArray(16);
//    env->SetByteArrayRegion(result, 0, 16, output);
//    return result;
//
//}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_aes_MainActivity_openssl_1encrypt(JNIEnv *env, jclass clazz, jbyteArray data,
                                                   jbyteArray key2) {
    // TODO: implement openssl_encrypt()


//    uint8_t key[16]  = {0x2b, 0x7e, 0x15, 0x16,
//                        0x28, 0xae, 0xd2, 0xa6,
//                        0xab, 0xf7, 0x15, 0x88,
//                        0x09, 0xcf, 0x4f, 0x3c};
//
//    uint8_t input[16]  = "hello, world!";

    jbyte *dataBytes = env->GetByteArrayElements(data, NULL);
    uint8_t input[16];
    memcpy(input, dataBytes, 16);
    env->ReleaseByteArrayElements(data, dataBytes, JNI_ABORT);  // JNI_ABORT 表示不拷贝回 Java 层

    // 3. 拷贝 key2 到 uint8_t key[16]
    jbyte *keyBytes = env->GetByteArrayElements(key2, NULL);
    uint8_t key[16];
    memcpy(key, keyBytes, 16);
    env->ReleaseByteArrayElements(key2, keyBytes, JNI_ABORT);


    struct AES_ctx ctx;
    AES_init_ctx(&ctx, key);
    AES_ECB_encrypt(&ctx, input);

    // 将加密结果转为十六进制字符串返回
    char hex[33] = {0};
    for (int i = 0; i < 16; ++i)
        sprintf(hex + i * 2, "%02x", input[i]);

    return env->NewStringUTF(hex);
}